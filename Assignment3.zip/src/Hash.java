import java.security.*;

public interface Hash {
	
	abstract String hashthis(String a) throws NoSuchAlgorithmException;	
	
}


